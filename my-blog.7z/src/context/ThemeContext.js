import { createContext } from 'react';

const themeContext = createContext();

export default themeContext;
